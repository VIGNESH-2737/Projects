package com.zsgs.theatrepass.screens.availableticket;

class AvailableTicketsViewModel {
	
	private AvailableTicketsScreen view;

	public AvailableTicketsViewModel(AvailableTicketsScreen screen) {
		view = screen;
	}
}
