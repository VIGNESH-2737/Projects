package com.zsgs.theatrepass.screens.availableticket;

import com.zsgs.theatrepass.BaseScreen;

public class AvailableTicketsScreen extends BaseScreen {
	private AvailableTicketsViewModel viewModel;

	public AvailableTicketsScreen() {
		viewModel = new AvailableTicketsViewModel(this);
	}

	public void onCreate() {

	}
}
