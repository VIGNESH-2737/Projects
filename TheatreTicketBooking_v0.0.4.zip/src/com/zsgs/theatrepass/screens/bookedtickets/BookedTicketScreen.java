package com.zsgs.theatrepass.screens.bookedtickets;

import com.zsgs.theatrepass.BaseScreen;

public class BookedTicketScreen extends BaseScreen {

	private BookedTicketViewModel viewModel;

	public BookedTicketScreen() {
		viewModel = new BookedTicketViewModel(this);
	}

	public void onCreate() {

	}
}
