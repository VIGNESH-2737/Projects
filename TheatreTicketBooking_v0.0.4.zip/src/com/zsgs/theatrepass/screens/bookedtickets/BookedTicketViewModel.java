package com.zsgs.theatrepass.screens.bookedtickets;

class BookedTicketViewModel {
	private BookedTicketScreen view;

	public BookedTicketViewModel(BookedTicketScreen screen) {
		view = screen;
	}
}
