package com.zsgs.theatrepass.screens.bookingscreen;

import com.zsgs.theatrepass.BaseScreen;

public class BookingScreen extends BaseScreen {
	private BookingScreenViewModel viewModel;

	public BookingScreen() {
		viewModel = new BookingScreenViewModel(this);
	}

	public void onCreate() {

	}
}
