package com.zsgs.theatrepass.screens.bookingscreen;

class BookingScreenViewModel {
	private BookingScreen view;

	public BookingScreenViewModel(BookingScreen screen) {
		view = screen;
	}
}
