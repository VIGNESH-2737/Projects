package com.zsgs.theatrepass;

public abstract class BaseScreen {

	public void showAlertMessage(String message) {
		System.out.println("Info: "+message);
	}
}
