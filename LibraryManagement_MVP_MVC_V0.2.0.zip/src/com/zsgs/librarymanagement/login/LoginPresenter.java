package com.zsgs.librarymanagement.login;

public interface LoginPresenter {

	void onSuccess();

	void onLoginFailed(String string);
	
}
