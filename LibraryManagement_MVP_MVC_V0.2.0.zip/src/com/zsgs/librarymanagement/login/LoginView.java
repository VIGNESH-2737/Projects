package com.zsgs.librarymanagement.login;

public interface LoginView {
	public void onSuccess();
	public void onLoginFailed(String alertText);
}
