package com.zsgs.librarymanagement.login;

public interface LoginModelPresenter {

	void onLoginFailed(String string);

	void onSuccess();

}
